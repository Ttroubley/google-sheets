# Changelog

TODO: set this up to be automated and pulled from git commits... for now just going to leave some notes manually!

### 3.2.0 (2021-11-07)

- Added `insertDimension` functionality
- Added custom header row index for row-based API
- Bumped dependency versions
- Readme/docs cleanup