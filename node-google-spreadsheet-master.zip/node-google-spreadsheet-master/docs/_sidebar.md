<!-- docs/_sidebar.md -->

* **Getting Started**
  * [Overview](/)
  * [Authentication](getting-started/authentication)
* **Full Class Reference**
  * [GoogleSpreadsheet](classes/google-spreadsheet)
  * [GoogleSpreadsheetWorksheet](classes/google-spreadsheet-worksheet)
  * [GoogleSpreadsheetCell](classes/google-spreadsheet-cell)
  * [GoogleSpreadsheetRow](classes/google-spreadsheet-row)