// This is a basic API key, used for making unauthenticated requests to public sheets

module.exports = 'AIzaSyB9HEJV4QWm5hbTOIEGQuBEyLFbx4s7bks';
